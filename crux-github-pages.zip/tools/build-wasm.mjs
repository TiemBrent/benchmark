import wabt from 'wabt';import fs from 'node:fs';
const w=await wabt();const module=w.parseWat('kernel',fs.readFileSync(new URL('../website/wasm/kernel.wat',import.meta.url),'utf8'));module.validate();fs.writeFileSync(new URL('../website/wasm/kernel.wasm',import.meta.url),module.toBinary({}).buffer);console.log('Compiled kernel.wasm');
