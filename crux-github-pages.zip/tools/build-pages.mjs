/** Dependency-free static build. Uses Node and the zip CLI supplied by GitHub runners. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const repository=process.env.GITHUB_REPOSITORY;
const site=process.env.SITE_URL;
if(!repository || !/^[\w.-]+\/[\w.-]+$/.test(repository))throw Error('Set GITHUB_REPOSITORY=OWNER/REPOSITORY');
if(!site)throw Error('Set SITE_URL=https://OWNER.github.io/REPOSITORY/');
const url=new URL(site);
if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash)throw Error('SITE_URL must be a clean HTTPS site URL.');
const output=path.join(root,'_site'),staging=path.join(root,'.release-staging'),artifacts=path.join(root,'release-artifacts');
for(const dir of [output,staging,artifacts]){fs.rmSync(dir,{recursive:true,force:true});fs.mkdirSync(dir,{recursive:true});}
fs.cpSync(path.join(root,'website'),output,{recursive:true});
const releaseUrl=`https://github.com/${repository}/releases`;
const hosting={provider:'github-pages',networkEndpoint:null,releaseUrl,extensionDownloadUrl:`${releaseUrl}/latest/download/crux-chrome-extension.zip`,siteUrl:url.href};
fs.writeFileSync(path.join(output,'hosting.js'),`export const HOSTING = ${JSON.stringify(hosting,null,2)};\n`);
fs.writeFileSync(path.join(output,'.nojekyll'),'');
fs.cpSync(path.join(root,'extension'),path.join(staging,'extension'),{recursive:true});
const manifestPath=path.join(staging,'extension','manifest.json');
const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
manifest.externally_connectable.matches=[`${url.protocol}//${url.hostname}/*`];
const tag=process.env.RELEASE_TAG;
if(tag){
  if(!/^v(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(tag))throw Error('Use a release tag such as v1.0.0 (no prerelease suffix).');
  if(tag.slice(1).split('.').some(n=>Number(n)>65535)||tag==='v0.0.0')throw Error('Invalid Chrome extension version.');
  manifest.version=tag.slice(1);
}
fs.writeFileSync(manifestPath,JSON.stringify(manifest,null,2)+'\n');
fs.writeFileSync(path.join(staging,'extension','allowed-origins.js'),`export const ALLOWED_ORIGINS = ${JSON.stringify([url.origin])};\n`);
fs.writeFileSync(path.join(staging,'INSTALL.md'),`# Crux ChromeOS extension ${manifest.version}\n\n1. Extract this ZIP.\n2. Open chrome://extensions in Chrome and enable Developer mode.\n3. Choose Load unpacked and select the extracted extension folder.\n4. Open ${url.href} and select ChromeOS extension.\n5. Paste the extension ID and click Connect bridge.\n\nAuthorized origin: ${url.origin}\nNo Python, server, popup, options page, or ChromeOS OS Developer Mode is needed.\nManaged Chromebooks may prohibit unpacked extensions.\n\nWebsite projects on the same origin share this trust boundary. Use a dedicated custom domain if other repositories on that origin are untrusted.\n`);
execFileSync('zip',['-qr',path.join(artifacts,'crux-chrome-extension.zip'),'extension','INSTALL.md'],{cwd:staging});
console.log(`Pages: ${output}\nExtension: ${path.join(artifacts,'crux-chrome-extension.zip')}\nAuthorized origin: ${url.origin}`);
