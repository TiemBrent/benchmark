export const SUITE_VERSION = '1.0.0';
export const CONFIG_VERSION = '1.0.0';
export const STANDARD_WEIGHTS = {cpu:25,gpu:20,webgpu:10,memory:10,storage:10,network:10,browser:5,rendering:5,media:5};
export const WEIGHTS = {...STANDARD_WEIGHTS};
export const CATEGORIES = {cpu:['CPU','▦','JavaScript, WASM & workers'],gpu:['GPU','◈','WebGL rendering'],webgpu:['WebGPU','⬡','GPU compute'],memory:['Memory','▥','Buffer throughput'],storage:['Storage','▤','IndexedDB & Cache'],network:['Network','↗','HTTP throughput & latency'],browser:['Browser','◎','DOM & responsiveness'],rendering:['Rendering','▱','Canvas & frame cadence'],media:['Media','▷','Audio, video & crypto context']};
