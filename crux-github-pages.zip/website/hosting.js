// Replaced with repository-specific values by tools/build-pages.mjs.
export const HOSTING = {
  provider: 'static',
  networkEndpoint: null,
  releaseUrl: null,
  extensionDownloadUrl: null,
  siteUrl: null
};
