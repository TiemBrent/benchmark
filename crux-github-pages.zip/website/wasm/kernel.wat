(module
 (func (export "kernel") (param $n i32) (param $x i32) (result i32)
  (local $i i32)
  (block $exit
   (loop $loop
    (br_if $exit (i32.ge_u (local.get $i) (local.get $n)))
    (local.set $x (i32.add (i32.mul (local.get $x) (i32.const 1664525)) (i32.const 1013904223)))
    (local.set $i (i32.add (local.get $i) (i32.const 1)))
    (br $loop)))
  (local.get $x)))
