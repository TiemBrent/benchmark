# ChromeOS bridge protocol v1

Connection: external runtime port named `crux-v1`. Sender URL and, where present, sender origin must be in the exact allowlist. No content script/window.postMessage forwarding exists.

Extension greeting:

```json
{"ok":true,"type":"EXTENSION_READY","data":{"version":"1.0.0","protocolVersion":1}}
```

Requests:

```json
{"type":"GET_SYSTEM_INFO","requestId":"req-1"}
{"type":"GET_CPU_INFO","requestId":"req-2"}
{"type":"START_MONITORING","requestId":"req-3"}
{"type":"STOP_MONITORING","requestId":"req-4"}
```

Responses always correlate `requestId`. GET prefix is removed from success type; failure type mirrors the request. Each component of system information has its own `{ok,data}` or `{ok:false,error}` so absent APIs do not discard the entire context. Storage API IDs are used only transiently for optional capacity queries, then removed from returned storage records.

```json
{"ok":false,"type":"GET_CPU_INFO","requestId":"req-2","error":"API_UNAVAILABLE"}
```

Telemetry uses `{ok, type:"TELEMETRY", data:{timestamp, temperatures, cpuUsage, totalUtilization, classification}}`. `cpuUsage` entries contain total/idle/user/kernel percentages derived from cumulative counter deltas. Empty temperature arrays and null utilization mean unavailable; never zero-as-missing. First sample has no delta. Phase labels are added by the website when received.

Sampling is 1 Hz, no configuration or arbitrary extension API dispatch is accepted. Requests require a string ID ≤100 characters. Unknown commands fail. Per-port commands are rate-limited to at least 50 ms apart. Stop/disconnect causes monitoring and keep-awake release once no active monitoring client remains. No battery API is invoked in the service worker.
