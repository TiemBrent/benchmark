# Scoring

No empirical Chromebook ranking dataset is bundled. Reference values are explicitly chosen **engineering anchors**, not a secretly measured reference device or percentiles. The suite is versioned and its score is not an industry-standard certification.

For raw median `x` and the workload's registry reference `r`:

- Throughput: `s = 100 * x / (x + r)`.
- Lower-is-better latency/jitter: `s = 100 * r / (x + r)`.
- At reference: 50/100. Extreme throughput approaches, but cannot exceed, 100.
- Invalid/non-finite results have no score; zero throughput is a real zero score.

Each category uses `exp(mean(log(max(0.001, s))))` over completed, scored tests. Sustained measurements are diagnostic and excluded. Epsilon is only for geometric-mean numerical stability. All samples, references, lower-is-better flags, median values, and normalized subtest scores are exported so the calculation is reproducible.

Standard category weights:

| Category | Weight |
|---|---:|
| CPU (JS, WASM, workers, Web Crypto) | 25% |
| GPU (WebGL) | 20% |
| WebGPU compute | 10% |
| Memory | 10% |
| Storage | 10% |
| Network | 10% |
| Browser (DOM, worker messaging, event loop) | 5% |
| Rendering (Canvas & observed cadence) | 5% |
| Media (audio/video) | 5% |

Overall is `round(10 * exp(sum(w_i * log(category_i)) / sum(w_i)))` over available categories only. Category coverage is the sum of included weights divided by all weights. Failed/unsupported tests are excluded, **not replaced by zero or guessed values**. The dashboard also reports completed test count, since category coverage alone can hide partial subtest coverage.

A score with missing GPU/network/media tests is not equivalent to a complete score. Compare exact completed test sets, modes, engine/config versions, weights, browser versions and power conditions. Local history rejects known mismatches; it cannot conclusively prove physical device identity. A reported difference is not statistical significance.

The network category uses bounded contributions for throughput, HTTP latency, jitter, and request reliability, so one very fast download cannot swamp everything else. Reliability uses the actual proportion of successful attempts. A completely unreachable endpoint is an unavailable test, not fabricated link reliability. Very low request counts limit confidence.

Scoring configuration is centralized in `website/config.js`. Changing `WEIGHTS` without changing `STANDARD_WEIGHTS` marks exported runs `customWeighting: true`. A public release changing benchmarks/references requires a suite/configuration version increment. The standard UI does not offer an accidental silent weighting override.

Dispersion is population variance of repeated values. `cv = standardDeviation / mean`; above 20% marks Low confidence. Samples are not discarded automatically. Extreme deviations (>3 standard deviations from median) are recorded, but three samples provide limited statistical power. Best is max throughput/min latency, median is primary. No CPU model/core-count/RAM-capacity/temperature/battery bonus is added.
