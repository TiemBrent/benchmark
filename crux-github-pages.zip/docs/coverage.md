# Release coverage and validation boundaries

This is an implemented, usable v1, not a claim that every variant in the 92-section specification is exhaustively completed. It includes approximately 100 workloads; exact count depends on safe worker counts. Everything displayed as a result is measured or directly reported.

## Implemented

- Responsive light/dark dashboard, accessible native controls/focus, reduced-motion policy, inline vector art, no runtime CDN.
- Quick/Full/Stress flows, central engine, warmup/repeats, measured stats, bounded scoring, individual raw sample charts/JSON, progress, pause/resume-between-tests, abort, hidden-tab invalidation.
- Multiple math workloads, sorting variants, sieve sizes, regex, JSON shapes, SHA-256/384/512 and AES-GCM, true compiled WASM + equivalent JS, practical worker scaling, worker round-trip/clone/transfer/shared atomic acknowledgement.
- 1/16/64 MiB allocation plus first touch; sequential buffer read/write, copy, fill, XOR.
- IndexedDB transaction reads/writes/deletes/random reads; Cache API read/write, unique namespaces and cleanup.
- WebGL2 drawing/instancing/particles/fill/complex shader/texture upload and mipmapping; actual WebGPU arithmetic, buffers, matrix and neighborhood-sum compute; adapter/device limits and loss/error handling.
- Canvas rectangle/path/text/image/transform/resize, worker OffscreenCanvas, DOM creation/attributes/query/flex/grid/reflow, rAF cadence under multiple loads and CSS animation types.
- Timer drift and optional long-task telemetry. Offline oscillator/mix/convolution audio. VP8 WebCodecs at three resolutions, decode capability hints for additional formats.
- Opt-in HTTP download/upload/latency/jitter/reliability; bounded server payload, no-cache responses; reported Network Information API context.
- Headless MV3 exact-origin messaging, READY handshake, minimal permissions, shared 1-second CPU/thermal telemetry, per-logical-CPU timing deltas, memory/storage/display/platform context, keep-awake/release lifecycle.
- Five-/ten-minute CPU sustained and shorter GPU sustained load, retention data, CPU performance line, thermal/utilization charts, synchronized phase/time metadata.
- Opt-in local history, JSON/CSV export, print dashboard, version-compatible comparisons, source archive, documentation and core tests.

## Deliberately limited / deferred

- No direct GC telemetry, fan speed, frequency, voltage, power draw, GPU temperature/utilization, per-core temperature mapping, or exact thermal-throttling state. Not exposed by this implementation's APIs.
- No attempt to guarantee stability through a browser-visible memory-pressure API; 256/512 MiB allocations and unbounded memory/storage stress are omitted.
- Worker latency is acknowledged round-trip, not fictitious independent directional clocks. SharedArrayBuffer test is one atomic acknowledged operation, not a full memory-throughput stress implementation.
- No live AudioWorklet callback stability/underrun benchmark or hardware/output latency measurement. Offline audio is labeled accordingly.
- Video encode/decode performance uses VP8 only in v1; other formats are capability detection, not claimed measured codec results.
- Display cadence uses short repeated windows (~2 seconds/test), not long-term panel certification. No advertised refresh Hz fabricated.
- Baseline is short CPU/thermal/battery context, not a complete independent idle network/memory/display profile. Battery is sampled before/after, not continuous electrical telemetry.
- Sustained CPU is single-worker, not all-core stress. Sustained GPU is repeated bounded batches, not uninterrupted render-state persistence. Recovery telemetry is 2 seconds only.
- No combined CPU+GPU+network+audio stress profile, scrolling/productivity/gaming profile, public database, anonymous submission, shared-result backend, accounts, public rankings or percentiles.
- No claims of genuine physical Chromebook certification from UA alone. Flex cannot reliably be ruled out. No platform-specific results or hardware records are hardcoded.
- Static hosting must supply its own compatible network endpoint/release archive. Compatible server is for development; production rate limiting, TLS/reverse proxy, capacity planning, and abuse protection remain deployment work.

## Validation

- Node tests cover statistics, normalization, missing-score coverage, real WASM correctness/equivalence, and headless extension permission structure.
- Automated browser checks cover workload execution, unsupported API fallback, full quick-run export/history, responsive overflow, and JS errors in headless Chromium.
- Headless browser scores are **not** evidence of physical Chromebook performance, hardware decoder use, or CPU temperature availability.
- Physical ChromeOS extension integration, sensor availability, power lifecycle under ChromeOS suspend, and full 5/10-minute hardware sustained runs must be tested on actual supported devices before a production release.

### Actual development checks performed

- End-to-end Quick run: 98 selected tests on a 2-logical-CPU headless Chromium environment; 93 completed, 5 correctly unsupported because no WebGPU adapter was available; no JavaScript page errors. Total run was approximately 66 seconds. Two additional sustained-only entries are present in the registry.
- Mobile viewport 390×844 had no horizontal page overflow.
- Unpacked extension loaded in desktop Chromium; actual external handshake, all five system-info API responses, CPU utilization telemetry, pause/resume, and abort/export paths worked. Desktop success does not validate ChromeOS thermal sensors.
- Real hardware WebGPU execution and long-duration physical-Chromebook stress remain unvalidated here. No headless score is preloaded into the product.
