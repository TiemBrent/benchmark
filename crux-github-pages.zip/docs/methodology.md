# Methodology — suite 1.0.0 / configuration 1.0.0

## Measurement pipeline

1. Detect browser/API capabilities, WebGL limits, optional WebGPU adapter, and media decoding capability hints.
2. Optionally connect the exact-origin MV3 bridge and fetch system information.
3. Collect a two-second idle telemetry baseline and reported battery state.
4. Execute registered workloads **serially**, warming each steady-state workload first.
5. Collect three repeated samples, except HTTP latency/quality (8 requests) and sustained runs (duration-based samples).
6. Isolate errors and unsupported tests; release each test's resources.
7. Collect final battery state and two seconds of recovery telemetry.
8. Calculate measured-only scores, export metadata and raw samples, optionally save locally.

Web worker CPU tests use deterministic input generators. Each worker warms for 120 ms; timed samples target 200 ms in Quick, 350 ms otherwise. Parallel worker tests use 300 ms intervals with up to 8 workers (bounded by reported logical concurrency). Workers warm independently and run concurrently; sample periods are not hardware-cycle synchronized. Total throughput is total work divided by the longest measured per-worker interval. Scaling efficiency is relative to the measured 1-worker run. Worker startup is explicitly a cold start measurement and is not warmed.

Non-worker workloads perform one untimed invocation before three measured invocations. Setup, shader compilation, generated inputs, and cleanup are generally outside steady-state samples. Work explicitly measuring allocation, DOM creation, texture upload, context creation, codec setup, or worker creation includes that setup. Latency and sample durations are in milliseconds. Bandwidth uses decimal MB/GB; buffer sizes use binary MiB when labeled MiB. Scores retain unrounded measurements.

## Hardware vs browser measurements

- CPU/JS: actual arithmetic, sorting, sieve, regex, JSON, and crypto operations. Timings include execution in the browser runtime, not just bare instructions.
- WASM: compiled i32 multiply/add recurrence, identical to the JS recurrence. Checksum prevents accidental unused outputs; test validates output equality.
- Memory: typed-array read/write/copy/fill/XOR and allocation plus page touching. Browser GC, optimizations, and caches contribute. No guarantee of physical DRAM bandwidth or deallocation latency.
- WebGL: 640×360 WebGL2 framebuffer, bounded draws, instancing, particles, shaders, texture upload/mipmaps. Completion uses `finish` plus actual `readPixels`, not merely command submission. Cooperative scheduler yielding is included; this is browser-completed workload throughput, not isolated GPU timer-query time. Particle “frames/s” is offscreen completed render throughput, not display scanout FPS.
- WebGPU: real WGSL storage-buffer compute, 64-wide workgroups, 65,536 elements, arithmetic/copy/256×256 matrix/dense neighborhood summation. Results include submission and mapped readback. “Reduction” here is independent neighborhood sums, not a fully hierarchical global reduction. Operation counts are defined in source; no assumed GPU clock.
- Canvas: 2D operations followed by readback; offscreen worker version uses 5,000 rectangles, main-thread uses 3,000. Compare operations/sec, not hypothetical FPS.
- Display: repeated requestAnimationFrame intervals, jitter, long frames, and estimated missed frame slots relative to sample median. No monitor-advertised Hz is invented. Load variants record cadence under DOM, Canvas, WebGL, WebGPU, and CSS animation. Offscreen GPU commands do not prove compositor or scanout performance.
- DOM/layout: measured creation, attribute/style updates, selector queries, flex/grid layout, forced geometry flushes, and removal. Combined setup/removal is included; these are not browser-internal layout-profiler counters.
- Event loop: setTimeout drift, optional Long Tasks count/duration/blocking observations. No claim of direct GC detection, actual user input latency, or attribution of pauses to GC.
- Storage: unique IndexedDB databases and Cache namespaces, transaction completion/read body consumption, automatic cleanup. Browser/page caches affect results. Deletion workloads re-seed entries outside each timed invocation. No fsync or guaranteed flash-write timing.
- Network: opt-in same-origin HTTP requests with nonce, cache disabled, uncompressed server payload, upload body disposal. Generated data only. HTTP overhead is included. Throughput is the route to this server, not an ISP rating. Reliability is successful requests divided by attempts; 8 requests are diagnostic, not a long-term SLA measurement.
- Audio: 48 kHz stereo OfflineAudioContext, 2 seconds of oscillator, mixing, or convolution output. This measures faster-than-real-time processing, not speakers, microphone, live callback underruns, or end-to-end audio latency.
- Video: support-checked VP8 encode/decode of 12 generated frames at 360p/720p/1080p. Encode, decode, counts, and durations are retained. This is a synthetic short clip; content does not represent arbitrary movies. Hardware acceleration is not assumed.

## Sustained tests

Full: CPU 300 seconds, GPU 30 seconds. Stress: CPU 600 seconds, GPU 120 seconds. CPU is a continuous **single worker** integer workload. GPU consists of repeated bounded 50K-particle batches, including shader/context reinitialization between batches; it is therefore a mixed sustained graphics workload, not an uninterrupted fixed GPU stress kernel.

Samples have elapsed time and wall timestamps. Retention is the mean of the last 5 samples divided by the mean of the first 5. Values are diagnostic, excluded from the standard score. Extension telemetry at 1 Hz carries phase IDs to align CPU use and thermal zones with samples. Recovery is a short 2-second observation, not proof of complete cooling. Sensor population can change; minimum/peak cover all reported sensors, means average available sensors. No sensor-to-core mapping or throttling attribution is made.

## Controls, safety, limitations

- Sequential benchmark execution and resource cleanup reduce interference.
- Worker count ≤8; individual memory buffers ≤64 MiB. Total process memory is not controlled by this bound. GC may retain prior allocations. No browser API guarantees detection before OOM; larger 256/512 MiB allocations are deliberately omitted.
- Temporary storage is only a few MiB per test, with a 32 MiB headroom check for IndexedDB. Browser quota/permission failures are reported, not ignored.
- Bounded network transfers ≤15 MB payload/run; networking must be enabled and Save-Data causes a skip.
- Standard test timeout 30 seconds. Workers and network can be forcibly canceled; synchronous DOM/graphics calls cannot be interrupted mid-call by a JS timeout. Finite workloads reduce that risk, but “never crashes any browser” cannot be guaranteed.
- Hidden tabs invalidate the current test and pause the queue, rather than reporting throttled background execution as normal performance.
- Warmup reduces, but does not eliminate, JIT/cache/thermal effects. Background OS work, browser updates, power management, and browser timer precision may still affect reproducibility.
