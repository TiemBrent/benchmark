# Crux — GitHub Pages + Chrome extension releases

The website runs entirely on **GitHub Pages**. The headless Chrome extension is distributed as **crux-chrome-extension.zip** through **GitHub Releases**. No Python, backend, account, or runtime build service is needed by users.

## 1. Upload the project

Create a GitHub repository (for example `crux`) with default branch `main`. Upload this project's contents to the repository root, **including `.github/workflows/`**. Do not upload only `website/` or put the entire project in an extra parent folder.

With Git installed:

```sh
git init -b main
git add .
git commit -m "Add Crux benchmark and Pages deployment"
git remote add origin https://github.com/YOUR-USERNAME/crux.git
git push -u origin main
```

Public repositories are the simplest route; private repository Pages availability depends on the GitHub plan.

## 2. Enable GitHub Pages

1. Open your repository → **Settings → Pages**.
2. Under **Build and deployment**, select **Source: GitHub Actions**.
3. Open **Actions → Deploy website to GitHub Pages → Run workflow** on `main`.
4. After the deployment succeeds, open the URL shown in the workflow or Pages settings, typically:
   `https://YOUR-USERNAME.github.io/crux/`.

Every subsequent push to `main` redeploys the website. Repository subpaths and user/organization root sites are supported. If you use a custom domain, configure it in Pages settings before building the extension release.

GitHub Actions uses Node 22 and the runner's `zip` command. No npm installation is required for deployment: compiled WebAssembly is already included. Only `_site/` is published; the extension service worker and source tools are not deployed as website scripts.

## 3. Publish the extension in Releases

After Pages has deployed successfully, push a semantic version tag:

```sh
git tag v1.0.0
git push origin v1.0.0
```

The **Publish Chrome extension release** workflow then:

- Reads your actual Pages URL, including a configured custom domain.
- Sets the extension's exact allowed origin to that website origin.
- Sets the extension manifest version from the tag.
- Creates a GitHub Release and attaches **crux-chrome-extension.zip**.

Use tags like `v1.0.0`, `v1.0.1`, `v1.1.0`. Chrome extension version components must be ≤65535; prerelease suffixes are not accepted by this build.

**Do not manually create a release first:** this workflow creates it from the pushed tag. The website's **Download ChromeOS extension** button targets the latest release asset. Before the first release exists, that URL will not have a file to download; the site says a release must be published first.

If changing the site's origin/custom domain, redeploy Pages and publish a new extension version. Users need to download/reload the newly authorized extension. Changing only the repository subpath on the same origin does not change origin authorization.

## 4. Install and connect on a Chromebook

1. Open the website → **ChromeOS extension** → **Download ChromeOS extension**.
2. Extract the ZIP.
3. Open `chrome://extensions` and enable the extension page's **Developer mode**.
4. Choose **Load unpacked** → select the extracted **extension/** directory.
5. Copy the extension ID, paste it into the website, and choose **Connect bridge**.

This does **not** require enabling ChromeOS OS Developer Mode. Managed school/work devices may prohibit unpacked extensions. A GitHub Release ZIP is not a Chrome Web Store installation and does not automatically update; download future releases manually and reload the extension.

The website works without the extension. The extension has no popup, options page, content script, or website host permissions; it uses only CPU/memory/storage/display/power APIs. Sender origins are checked both by the manifest and the service worker. Temperature data, when present on physical ChromeOS, is thermal-zone data, not individual core temperatures.

### Origin trust boundary

The configured origin is `https://YOUR-USERNAME.github.io`, **not** the `/crux/` repository path. Other Pages projects on the same origin share that trust boundary and also share origin-scoped browser storage. Use a dedicated custom domain if other same-origin projects are untrusted. No wildcard host is allowed.

## GitHub Pages limitations

- **Network benchmarks:** unavailable, explicitly disabled. Pages cannot run the upload/download measurement server. Network Information API hints may still be reported; they are not measured speed-test results. No external testing service is silently contacted.
- **SharedArrayBuffer test:** usually unavailable because Pages does not let this deployment set COOP/COEP response headers. It is gracefully skipped. Regular Web Workers and worker scaling still run.
- **Other APIs:** WebGPU, codecs, battery, and ChromeOS telemetry depend on browser/device support and remain detected at runtime.
- Missing categories are excluded from scoring and coverage is shown. Do not compare Pages scores to a full backend-enabled result as though coverage were identical.

## Optional local development — Node only

```sh
npm start                       # Node static preview at http://localhost:3000
npm test                        # Built-in Node tests, no install needed
```

No server is needed for GitHub Pages itself. The local preview deliberately behaves like static hosting (no network endpoint or custom isolation headers).

To rebuild WASM only:

```sh
npm install
node tools/build-wasm.mjs
```

To manually configure the source extension for a local/custom origin:

```sh
node tools/configure-extension.mjs https://YOUR-USERNAME.github.io
```

For a local test of the exact Pages build (POSIX shell; requires `zip`):

```sh
GITHUB_REPOSITORY=YOUR-USERNAME/crux \
SITE_URL=https://YOUR-USERNAME.github.io/crux/ \
node tools/build-pages.mjs
node tools/serve.mjs _site
```

## Files

- `.github/workflows/pages.yml` — deploy website on main pushes/manual run.
- `.github/workflows/release.yml` — publish extension ZIP on version-tag pushes.
- `website/` — static UI, benchmark engine, workers, compiled WASM.
- `extension/` — headless Manifest V3 source; localhost allowed by default.
- `tools/build-pages.mjs` — generates deployment config and release ZIP; no Python/dependencies.
- `docs/` — measurement methodology, scoring, protocol, coverage boundaries.

See `docs/coverage.md` for deferred workload variants and physical-Chromebook validation limits. A functional build is not a claim that every possible benchmark variant or actual device configuration has been validated.
