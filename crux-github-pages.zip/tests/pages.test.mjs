import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';

test('Pages build supports repository paths and configures release extension',()=>{
  execFileSync(process.execPath,['tools/build-pages.mjs'],{env:{...process.env,GITHUB_REPOSITORY:'test-owner/crux',SITE_URL:'https://test-owner.github.io/crux/',RELEASE_TAG:'v1.2.3'}});
  const hosting=fs.readFileSync('_site/hosting.js','utf8');
  assert.ok(hosting.includes('https://github.com/test-owner/crux/releases/latest/download/crux-chrome-extension.zip'));
  assert.ok(hosting.includes('"networkEndpoint": null'));
  const manifest=JSON.parse(execFileSync('unzip',['-p','release-artifacts/crux-chrome-extension.zip','extension/manifest.json'],{encoding:'utf8'}));
  assert.equal(manifest.version,'1.2.3');
  assert.deepEqual(manifest.externally_connectable.matches,['https://test-owner.github.io/*']);
  const origins=execFileSync('unzip',['-p','release-artifacts/crux-chrome-extension.zip','extension/allowed-origins.js'],{encoding:'utf8'});
  assert.ok(origins.includes('https://test-owner.github.io'));
  assert.ok(!origins.includes('/crux'));
  assert.ok(fs.existsSync('_site/wasm/kernel.wasm'));
  assert.ok(fs.existsSync('_site/.nojekyll'));
  const html=fs.readFileSync('_site/index.html','utf8');
  assert.ok(!html.includes('/download/project.zip'));
  assert.ok(!html.includes('python3'));
});
